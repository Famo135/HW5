//40223076 Fatemeh Moghiseh

#include <stdio.h>

int main() {

    //دریافت تعداد کاراکتر مدنظر
    int i=1,n,flag=0;
    printf("Please enter the number of characters: ");
    scanf("%d", &n);
    
    //دریافت کاراکتر از کاربر
    char character[n+1];
    printf("Please enter %d characters: "  , n);
    scanf("%s" , character);
    
    //مرحله به مرحله حذف کاراکتر های مشابه کنار هم و پرینت هر مرحله
    for( i ; i<=n ; i++ ) {
        if(character[i-1]==character[i]) {
            for(int j=i ; j<=n ; j++)
            character[j-1]=character[j+1];
            i=i-2;
            flag++;
            printf("%dth output:  %s\n" ,flag, character);
        }
        
    }

return 0;
}


    
